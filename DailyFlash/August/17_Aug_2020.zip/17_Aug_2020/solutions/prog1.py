
list = [int(a) for  a in input("Enter the Integer values from user. ").split()]


print(list)
