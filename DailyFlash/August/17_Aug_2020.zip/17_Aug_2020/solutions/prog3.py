
list = [int(a) for  a in input("Enter the Integer values. ").split()]

for a in list:
    print(chr(a),end="")



