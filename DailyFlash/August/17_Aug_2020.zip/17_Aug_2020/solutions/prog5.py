name = input("Enter your name: ")

print("My name is {}".format(name))
