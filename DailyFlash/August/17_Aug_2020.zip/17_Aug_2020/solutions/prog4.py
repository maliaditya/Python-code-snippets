cricketTeam = {}


cricketTeam[int(input("enter the jersey number"))] = input("enter the name of player")
cricketTeam[int(input("enter the jersey number"))] = input("enter the name of player")


for a in cricketTeam:
    print(cricketTeam[a])