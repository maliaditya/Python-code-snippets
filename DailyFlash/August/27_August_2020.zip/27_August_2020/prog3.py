import random
a = [random.randint(1,100) for a in range(10)]
print(a)