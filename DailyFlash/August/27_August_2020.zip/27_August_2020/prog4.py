import random
dishes = ['Chopsy','Fries','Scrambled-Egg','Chicken 65']

print("Here is your special dish: ", random.choice(dishes))