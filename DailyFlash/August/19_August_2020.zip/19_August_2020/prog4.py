infinity_war_cast = ("Ruffalo","Holand","Brolin","RDJ","Evans","Cumberbatch","Hemsworth")
deadpool2_cast =["Brolin","Reynolds","Karan Soni","Matt Damon"]

set= {x for x in infinity_war_cast if x not in deadpool2_cast}
print(set)