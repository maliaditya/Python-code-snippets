developers = ['Linus Torvalds','Guido Van Russom','James Gosling','Dennis Ritchie']
work = ['Linux','python','Java','C & Unix']

a = zip(developers,work)
print(frozenset(a))