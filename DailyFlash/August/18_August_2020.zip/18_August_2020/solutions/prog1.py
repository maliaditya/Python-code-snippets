guest = ['Aunt(paternal)','Grandpa','Grandma','Aunt(paternal)','Uncle(Maternal)','Uncle(Maternal)']

guest = {a for a in guest}

guest = tuple(guest)

print(guest)


